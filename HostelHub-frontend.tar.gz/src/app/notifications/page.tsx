"use client";
import { useState } from "react";
import { useNotifications } from "@/hooks/useNotifications";
import { Bell, CheckCheck, MessageCircle, ClipboardList, Heart, CheckCircle, Package, Info } from "lucide-react";
import { useRouter } from "next/navigation";
import { Skeleton } from "@/components/ui/Skeleton";
import PageTransition from "@/components/PageTransition";
import clsx from "clsx";
import type { Notification, NotificationType } from "@/types/notification";

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

const TYPE_ICON: Record<NotificationType, React.ReactNode> = {
  message:    <MessageCircle className="w-4 h-4" />,
  poll_reply: <ClipboardList className="w-4 h-4" />,
  wishlist:   <Heart className="w-4 h-4" />,
  sold:       <CheckCircle className="w-4 h-4" />,
  listing:    <Package className="w-4 h-4" />,
  system:     <Info className="w-4 h-4" />,
};

const TYPE_COLOR: Record<NotificationType, string> = {
  message:    "bg-indigo-100 text-indigo-600 dark:bg-indigo-900/50 dark:text-indigo-400",
  poll_reply: "bg-amber-100 text-amber-600 dark:bg-amber-900/50 dark:text-amber-400",
  wishlist:   "bg-rose-100 text-rose-600 dark:bg-rose-900/50 dark:text-rose-400",
  sold:       "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/50 dark:text-emerald-400",
  listing:    "bg-violet-100 text-violet-600 dark:bg-violet-900/50 dark:text-violet-400",
  system:     "bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-400",
};

function NotifRow({ n, onRead }: { n: Notification; onRead: (id: string) => void }) {
  const router = useRouter();
  return (
    <button onClick={() => { onRead(n.id); if (n.link) router.push(n.link); }}
      className={clsx(
        "w-full flex items-start gap-4 px-5 py-4 text-left transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/40",
        !n.read && "bg-indigo-50/50 dark:bg-indigo-950/20"
      )}>
      <div className="relative flex-shrink-0">
        {n.avatar ? (
          <img src={n.avatar} alt="" className="w-10 h-10 rounded-full" />
        ) : (
          <div className={clsx("w-10 h-10 rounded-xl flex items-center justify-center", TYPE_COLOR[n.type])}>
            {TYPE_ICON[n.type]}
          </div>
        )}
        {!n.read && (
          <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-indigo-500 rounded-full border-2 border-white dark:border-slate-800" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className={clsx("text-sm leading-snug", n.read ? "text-slate-600 dark:text-slate-400" : "font-semibold text-slate-800 dark:text-slate-100")}>
          {n.title}
        </p>
        <p className="text-sm text-slate-400 dark:text-slate-500 mt-0.5 line-clamp-2 leading-relaxed">{n.message}</p>
        <p className="text-xs text-slate-300 dark:text-slate-600 mt-1.5">{timeAgo(n.createdAt)}</p>
      </div>
    </button>
  );
}

export default function NotificationsPage() {
  const [page, setPage] = useState(1);
  const { data, isLoading, markAllRead, markOneRead } = useNotifications(page);

  const notifications = data?.notifications ?? [];
  const unreadCount = data?.unreadCount ?? 0;
  const total = data?.total ?? 0;

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="max-w-2xl mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center">
                <Bell className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100">Notifications</h1>
                {unreadCount > 0 && (
                  <p className="text-xs text-indigo-500 dark:text-indigo-400">{unreadCount} unread</p>
                )}
              </div>
            </div>
            {unreadCount > 0 && (
              <button onClick={markAllRead}
                className="flex items-center gap-1.5 text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 transition-colors">
                <CheckCheck className="w-4 h-4" />Mark all as read
              </button>
            )}
          </div>

          {/* List */}
          <div className="backdrop-blur-sm bg-white/80 dark:bg-slate-800/80 border border-white/60 dark:border-white/10 rounded-2xl shadow overflow-hidden divide-y divide-slate-50 dark:divide-slate-700/50">
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <div key={i} className="flex items-start gap-4 px-5 py-4">
                  <Skeleton className="w-10 h-10 rounded-xl flex-shrink-0" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-3 w-1/2" />
                    <Skeleton className="h-2.5 w-3/4" />
                    <Skeleton className="h-2 w-1/4" />
                  </div>
                </div>
              ))
            ) : notifications.length === 0 ? (
              <div className="flex flex-col items-center py-16 gap-3">
                <Bell className="w-10 h-10 text-slate-200 dark:text-slate-600" />
                <p className="text-slate-400 dark:text-slate-500 font-medium">All caught up!</p>
                <p className="text-slate-300 dark:text-slate-600 text-sm">No notifications yet</p>
              </div>
            ) : (
              notifications.map(n => (
                <NotifRow key={n.id} n={n} onRead={markOneRead} />
              ))
            )}
          </div>

          {/* Pagination */}
          {total > 20 && (
            <div className="flex justify-center gap-2 mt-6">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="px-4 py-2 text-sm font-medium rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all text-slate-600 dark:text-slate-300">
                Previous
              </button>
              <span className="px-4 py-2 text-sm text-slate-400 dark:text-slate-500">Page {page}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={notifications.length < 20}
                className="px-4 py-2 text-sm font-medium rounded-xl border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all text-slate-600 dark:text-slate-300">
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  );
}
