"use client";
import { useWishlist } from "@/hooks/useWishlist";
import { useProducts } from "@/hooks/useProducts";
import Link from "next/link";
import { Heart, ShoppingBag } from "lucide-react";
import WishlistButton from "@/components/WishlistButton";
import type { Product } from "@/types";

function WishlistCard({ p }: { p: Product }) {
  return (
    <div className="group relative backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl overflow-hidden shadow hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
      <Link href={`/product/${p.id}`}>
        <div className="relative aspect-square overflow-hidden bg-slate-100">
          <img src={p.imageUrl} alt={p.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        </div>
      </Link>
      <div className="absolute top-2 right-2">
        <WishlistButton productId={p.id} size="sm" />
      </div>
      <div className="p-3">
        <Link href={`/product/${p.id}`}>
          <p className="text-sm font-semibold text-slate-700 line-clamp-2 leading-snug hover:text-indigo-600 transition-colors">{p.title}</p>
        </Link>
        <div className="flex items-center justify-between mt-2">
          <p className="text-base font-bold text-indigo-600">₹{p.price.toLocaleString()}</p>
          <span className="text-xs text-slate-400">{p.hostelId}</span>
        </div>
        {p.sold && (
          <p className="text-xs text-red-500 font-medium mt-1">• Sold</p>
        )}
      </div>
    </div>
  );
}

export default function WishlistPage() {
  const { ids } = useWishlist();
  const { data } = useProducts({ limit: 100 });

  const allProducts = data?.products ?? [];
  const wishlisted = allProducts.filter(p => ids.includes(p.id));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center">
            <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Wishlist</h1>
            <p className="text-sm text-slate-500">{ids.length} saved item{ids.length !== 1 ? "s" : ""}</p>
          </div>
        </div>

        {ids.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <div className="w-20 h-20 rounded-2xl bg-slate-100 flex items-center justify-center">
              <Heart className="w-9 h-9 text-slate-300" />
            </div>
            <p className="text-slate-500 font-medium">Your wishlist is empty</p>
            <p className="text-slate-400 text-sm">Tap the heart on any listing to save it here</p>
            <Link href="/products"
              className="mt-2 flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-5 rounded-xl shadow-md shadow-indigo-200 transition-all duration-200">
              <ShoppingBag className="w-4 h-4" />
              Browse Listings
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
            {wishlisted.map(p => <WishlistCard key={p.id} p={p} />)}
          </div>
        )}

        {ids.length > 0 && wishlisted.length === 0 && (
          <p className="text-center text-slate-400 mt-10 text-sm">Loading saved items...</p>
        )}
      </div>
    </div>
  );
}
