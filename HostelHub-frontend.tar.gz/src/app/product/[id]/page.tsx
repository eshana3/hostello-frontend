"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { fetchProductById } from "@/lib/api";
import { useRecentlyViewed } from "@/hooks/useRecentlyViewed";
import ImageGallery from "@/components/ImageGallery";
import WishlistButton from "@/components/WishlistButton";
import RelatedProducts from "@/components/RelatedProducts";
import {
  MapPin, Tag, Clock, MessageCircle, CheckCircle, ArrowLeft,
  ShieldCheck, Eye, MessageSquare
} from "lucide-react";
import Link from "next/link";
import clsx from "clsx";

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { add } = useRecentlyViewed();
  const [startingChat, setStartingChat] = useState(false);

  const { data, isLoading, isError } = useQuery({
    queryKey: ["product", id],
    queryFn: () => fetchProductById(id),
    enabled: !!id,
  });

  useEffect(() => {
    if (data?.product) add(data.product);
  }, [data?.product]);

  const handleStartChat = async () => {
    if (!data?.product) return;
    setStartingChat(true);
    try {
      const res = await fetch("/api/chats", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: data.product.id,
          sellerId: data.product.sellerId,
          sellerName: data.product.sellerName,
          productTitle: data.product.title,
          productImageUrl: data.product.imageUrl,
        }),
      });
      const chat = await res.json();
      router.push(`/chats/${chat.id}`);
    } catch {
      setStartingChat(false);
    }
  };

  if (isLoading) return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 flex items-center justify-center">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-500 rounded-full animate-spin" />
        <p className="text-slate-500 text-sm">Loading listing...</p>
      </div>
    </div>
  );

  if (isError || !data) return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 flex items-center justify-center">
      <div className="text-center">
        <p className="text-slate-500 mb-4">Listing not found.</p>
        <button onClick={() => router.back()} className="text-indigo-500 hover:underline">Go back</button>
      </div>
    </div>
  );

  const { product: p, related } = data;

  const images = p.imageUrl
    ? [p.imageUrl, p.imageUrl, p.imageUrl]
    : ["https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=600&q=80"];

  const conditionColor: Record<string, string> = {
    "Like New": "bg-emerald-100 text-emerald-700",
    "Good": "bg-blue-100 text-blue-700",
    "Fair": "bg-amber-100 text-amber-700",
    "Poor": "bg-red-100 text-red-700",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <button onClick={() => router.back()}
          className="flex items-center gap-1.5 text-slate-500 hover:text-slate-800 mb-6 transition-colors group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span className="text-sm font-medium">Back</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
          <div>
            <ImageGallery images={images} alt={p.title} />
          </div>

          <div className="flex flex-col gap-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  {p.sold && (
                    <span className="text-xs font-semibold bg-slate-800 text-white px-2.5 py-1 rounded-full">SOLD</span>
                  )}
                  <span className={clsx("text-xs font-medium px-2.5 py-1 rounded-full", conditionColor[p.condition] || "bg-slate-100 text-slate-600")}>
                    {p.condition}
                  </span>
                  {p.negotiable && (
                    <span className="text-xs font-medium bg-violet-100 text-violet-700 px-2.5 py-1 rounded-full">Negotiable</span>
                  )}
                </div>
                <h1 className="text-2xl font-bold text-slate-800 leading-snug">{p.title}</h1>
              </div>
              <WishlistButton productId={p.id} size="md" className="flex-shrink-0 mt-1" />
            </div>

            <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-4 shadow">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-indigo-600">₹{p.price.toLocaleString()}</span>
                {p.negotiable && <span className="text-sm text-slate-400">· price negotiable</span>}
              </div>
            </div>

            <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-4 shadow space-y-3">
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <MapPin className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                <span>Listed from <span className="font-semibold text-slate-800">{p.hostelId}</span></span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Tag className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                <span>Category: <span className="font-semibold text-slate-800">{p.category}</span></span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Eye className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                <span><span className="font-semibold text-slate-800">{p.views ?? 0}</span> views</span>
              </div>
              {p.createdAt && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Clock className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                  <span>Posted <span className="font-semibold text-slate-800">{new Date(p.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span></span>
                </div>
              )}
            </div>

            {p.description && (
              <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-4 shadow">
                <h3 className="text-sm font-semibold text-slate-700 mb-2">Description</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{p.description}</p>
              </div>
            )}

            <Link href={`/seller/${p.sellerId}`}
              className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-4 shadow hover:shadow-md transition-all duration-200 flex items-center gap-3 group">
              <img
                src={`https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(p.sellerName)}&backgroundColor=6366f1`}
                alt={p.sellerName}
                className="w-11 h-11 rounded-full bg-indigo-100"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">{p.sellerName}</p>
                <p className="text-xs text-slate-500">{p.hostelId} · View profile →</p>
              </div>
              <ShieldCheck className="w-4 h-4 text-emerald-500 flex-shrink-0" />
            </Link>

            {/* CTA buttons — both kept */}
            {!p.sold && (
              <div className="flex flex-col gap-2">
                {/* HostelMarket Chat (new) */}
                <button
                  onClick={handleStartChat}
                  disabled={startingChat}
                  className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-70 text-white font-semibold py-3 px-4 rounded-xl shadow-md shadow-indigo-200 hover:shadow-lg transition-all duration-200">
                  <MessageSquare className="w-4 h-4" />
                  {startingChat ? "Opening chat..." : "Chat with Seller"}
                </button>
                {/* WhatsApp (existing — kept) */}
                <a
                  href={`https://wa.me/?text=Hi! I'm interested in your listing: ${encodeURIComponent(p.title)} for ₹${p.price} on HostelHubu.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 bg-white border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50 text-slate-700 font-semibold py-3 px-4 rounded-xl transition-all duration-200">
                  <MessageCircle className="w-4 h-4 text-emerald-500" />
                  Chat on WhatsApp
                </a>
              </div>
            )}

            {p.sold && (
              <div className="flex items-center gap-2 text-sm text-slate-500 bg-slate-100 rounded-xl px-4 py-3">
                <CheckCircle className="w-4 h-4 text-slate-400" />
                This item has been sold
              </div>
            )}
          </div>
        </div>

        <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-6 shadow">
          <RelatedProducts products={related} />
        </div>
      </div>
    </div>
  );
}
