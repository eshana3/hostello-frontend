"use client";
import { Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import FilterSidebar from "@/components/FilterSidebar";
import ProductGrid from "@/components/ProductGrid";
import Pagination from "@/components/Pagination";
import { useProducts } from "@/hooks/useProducts";
import type { ProductFilters } from "@/types";
import { SlidersHorizontal, Search } from "lucide-react";
import { useState } from "react";

function ProductsContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  const filters: ProductFilters = {
    category:  searchParams.get("category")  ?? undefined,
    hostel:    searchParams.get("hostel")    ?? undefined,
    condition: searchParams.get("condition") ?? undefined,
    minPrice:  searchParams.get("minPrice")  ? Number(searchParams.get("minPrice"))  : undefined,
    maxPrice:  searchParams.get("maxPrice")  ? Number(searchParams.get("maxPrice"))  : undefined,
    search:    searchParams.get("search")    ?? undefined,
    page:      Number(searchParams.get("page") ?? 1),
    limit:     12,
  };

  const { data, isLoading, isError } = useProducts(filters);

  function updateFilter(key: string, value: string | null) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    if (key !== "page") params.delete("page");
    router.push(`/products?${params.toString()}`);
  }

  const activeCount = ["category","hostel","condition","minPrice","maxPrice","search"]
    .filter((k) => searchParams.get(k)).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {filters.category ? `${filters.category}` : "All Products"}
          </h1>
          {data && (
            <p className="text-sm text-gray-500 mt-1">
              {data.total} product{data.total !== 1 ? "s" : ""} found
            </p>
          )}
        </div>

        {/* Search bar */}
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search..."
            defaultValue={filters.search ?? ""}
            onKeyDown={(e) => {
              if (e.key === "Enter") updateFilter("search", (e.target as HTMLInputElement).value || null);
            }}
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
          />
        </div>

        {/* Mobile filter toggle */}
        <button
          onClick={() => setShowMobileFilters(true)}
          className="lg:hidden flex items-center gap-2 border border-gray-200 rounded-lg px-3 py-2 text-sm"
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filters {activeCount > 0 && <span className="bg-indigo-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{activeCount}</span>}
        </button>
      </div>

      {/* Mobile filter drawer */}
      {showMobileFilters && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowMobileFilters(false)} />
          <div className="absolute right-0 top-0 h-full w-80 bg-white p-4 overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg">Filters</h3>
              <button onClick={() => setShowMobileFilters(false)} className="text-gray-500 text-2xl leading-none">&times;</button>
            </div>
            <FilterSidebar filters={filters} onFilterChange={(k, v) => { updateFilter(k, v); setShowMobileFilters(false); }} />
          </div>
        </div>
      )}

      {/* Main layout */}
      <div className="flex gap-6">
        <FilterSidebar filters={filters} onFilterChange={updateFilter} />
        <div className="flex-1 min-w-0">
          <ProductGrid products={data?.products ?? []} isLoading={isLoading} isError={isError} />
          {data && (
            <Pagination
              currentPage={data.page}
              totalPages={data.totalPages}
              onPageChange={(p) => updateFilter("page", String(p))}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center py-40 text-gray-400">Loading...</div>}>
      <ProductsContent />
    </Suspense>
  );
}
