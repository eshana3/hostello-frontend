import type { Metadata } from "next";
import "./globals.css";
import QueryProvider from "@/providers/QueryProvider";
import { SocketProvider } from "@/providers/SocketProvider";
import { ToastProvider } from "@/providers/ToastProvider";
import { ThemeProvider } from "@/providers/ThemeProvider";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BottomNav from "@/components/BottomNav";
import { Toaster } from "sonner";

export const metadata: Metadata = {
  title: "HostelMarket – Buy & Sell on Campus",
  description: "The easiest way to buy and sell within your hostel campus",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="font-sans antialiased">
        <ThemeProvider>
          <QueryProvider>
            <SocketProvider>
              <ToastProvider>
                <Navbar />
                <div className="pb-16 md:pb-0">
                  {children}
                </div>
                <div className="hidden md:block">
                  <Footer />
                </div>
                <BottomNav />
                <Toaster
                  position="bottom-right"
                  toastOptions={{
                    style: {
                      background: "var(--toast-bg, white)",
                      border: "1px solid rgba(226,232,240,1)",
                      borderRadius: "12px",
                      fontSize: "13px",
                    },
                  }}
                />
              </ToastProvider>
            </SocketProvider>
          </QueryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
