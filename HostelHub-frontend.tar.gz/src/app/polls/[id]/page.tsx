"use client";
import { useState, FormEvent } from "react";
import { useParams, useRouter } from "next/navigation";
import { usePoll } from "@/hooks/usePolls";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/providers/ToastProvider";
import { CURRENT_USER_ID } from "@/lib/mockChats";
import {
  ArrowLeft, MessageSquare, Clock, IndianRupee, CheckCircle,
  XCircle, MapPin, Tag, Send
} from "lucide-react";
import clsx from "clsx";

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

export default function PollDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data, isLoading, isError } = usePoll(id);

  const [replyMsg, setReplyMsg] = useState("");
  const [replyPrice, setReplyPrice] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [closing, setClosing] = useState(false);

  const handleReply = async (e: FormEvent) => {
    e.preventDefault();
    if (!replyMsg.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/polls/${id}/reply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: replyMsg.trim(), price: replyPrice || undefined }),
      });
      if (!res.ok) throw new Error("Failed");
      await queryClient.invalidateQueries({ queryKey: ["poll", id] });
      await queryClient.invalidateQueries({ queryKey: ["polls"] });
      toast("Reply sent successfully!", "success");
      setReplyMsg("");
      setReplyPrice("");
    } catch {
      toast("Failed to send reply.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = async () => {
    setClosing(true);
    try {
      await fetch(`/api/polls/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "closed" }),
      });
      await queryClient.invalidateQueries({ queryKey: ["poll", id] });
      await queryClient.invalidateQueries({ queryKey: ["polls"] });
      toast("Request marked as closed.", "info");
    } catch {
      toast("Failed to close request.", "error");
    } finally {
      setClosing(false);
    }
  };

  if (isLoading) return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 flex items-center justify-center">
      <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-500 rounded-full animate-spin" />
    </div>
  );

  if (isError || !data) return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 flex items-center justify-center">
      <p className="text-slate-500">Request not found.</p>
    </div>
  );

  const { poll, replies } = data;
  const isOwner = poll.buyerId === CURRENT_USER_ID;
  const isOpen = poll.status === "open";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <button onClick={() => router.back()}
          className="flex items-center gap-1.5 text-slate-500 hover:text-slate-800 mb-6 transition-colors group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span className="text-sm font-medium">All Requests</span>
        </button>

        {/* Poll card */}
        <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-5 shadow-lg mb-5">
          <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={clsx(
                "text-xs font-semibold px-2.5 py-1 rounded-full",
                isOpen ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"
              )}>
                {isOpen ? "Open" : "Closed"}
              </span>
              <span className="text-xs bg-indigo-50 text-indigo-600 font-medium px-2.5 py-1 rounded-full flex items-center gap-1">
                <Tag className="w-3 h-3" />{poll.category}
              </span>
            </div>
            {isOwner && isOpen && (
              <button onClick={handleClose} disabled={closing}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-red-600 border border-slate-200 hover:border-red-200 px-3 py-1.5 rounded-xl transition-all disabled:opacity-50">
                <XCircle className="w-3.5 h-3.5" />
                {closing ? "Closing..." : "Mark as Closed"}
              </button>
            )}
          </div>

          <h1 className="text-xl font-bold text-slate-800 mb-2">{poll.itemName}</h1>
          <p className="text-sm text-slate-600 leading-relaxed mb-4">{poll.description}</p>

          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-1.5 text-slate-500">
              <img src={poll.buyerAvatar} alt={poll.buyerName} className="w-5 h-5 rounded-full" />
              <span className="font-medium text-slate-700">{poll.buyerName}</span>
            </div>
            <div className="flex items-center gap-1 text-slate-500">
              <MapPin className="w-3.5 h-3.5" />{poll.hostelId}
            </div>
            <div className="flex items-center gap-1 text-slate-500">
              <Clock className="w-3.5 h-3.5" />{timeAgo(poll.createdAt)}
            </div>
            {poll.maxPrice && (
              <div className="flex items-center gap-1 text-violet-600 font-semibold">
                <IndianRupee className="w-3.5 h-3.5" />Budget: up to ₹{poll.maxPrice.toLocaleString()}
              </div>
            )}
          </div>
        </div>

        {/* Replies */}
        <div className="mb-5">
          <h2 className="text-base font-bold text-slate-700 mb-3 flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-indigo-400" />
            {replies.length} {replies.length === 1 ? "Reply" : "Replies"}
          </h2>

          {replies.length === 0 ? (
            <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-6 text-center shadow">
              <MessageSquare className="w-8 h-8 text-slate-200 mx-auto mb-2" />
              <p className="text-sm text-slate-400">No replies yet. Be the first seller to respond!</p>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {replies.map(r => (
                <div key={r.id} className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-4 shadow">
                  <div className="flex items-center justify-between gap-3 mb-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      <img src={r.sellerAvatar} alt={r.sellerName} className="w-8 h-8 rounded-full" />
                      <div>
                        <p className="text-sm font-semibold text-slate-800">{r.sellerName}</p>
                        <p className="text-xs text-slate-400">{timeAgo(r.createdAt)}</p>
                      </div>
                    </div>
                    {r.price && (
                      <span className="text-sm font-black text-indigo-600 bg-indigo-50 px-3 py-1 rounded-xl">
                        ₹{r.price.toLocaleString()}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">{r.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reply form */}
        {isOpen && !isOwner && (
          <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-5 shadow-lg">
            <h3 className="text-base font-bold text-slate-800 mb-4">Send a Reply</h3>
            <form onSubmit={handleReply} className="flex flex-col gap-3">
              <textarea
                value={replyMsg} onChange={e => setReplyMsg(e.target.value)}
                placeholder="Describe what you have and why it matches their request..."
                rows={3}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:bg-white transition-all resize-none leading-relaxed"
              />
              <div className="flex gap-3">
                <div className="relative flex-1">
                  <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                  <input
                    value={replyPrice} onChange={e => setReplyPrice(e.target.value)}
                    type="number" placeholder="Your price (optional)"
                    className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:bg-white transition-all"
                  />
                </div>
                <button type="submit" disabled={submitting || !replyMsg.trim()}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-semibold px-5 py-2.5 rounded-xl shadow-md shadow-indigo-200 transition-all duration-200">
                  <Send className="w-4 h-4" />
                  {submitting ? "Sending..." : "Reply"}
                </button>
              </div>
            </form>
          </div>
        )}

        {isOwner && isOpen && (
          <div className="backdrop-blur-sm bg-emerald-50 border border-emerald-100 rounded-2xl p-4 text-sm text-emerald-700 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 flex-shrink-0" />
            This is your request. Mark it as closed once you've found what you need.
          </div>
        )}

        {!isOpen && (
          <div className="backdrop-blur-sm bg-slate-50 border border-slate-100 rounded-2xl p-4 text-sm text-slate-500 flex items-center gap-2">
            <XCircle className="w-4 h-4 flex-shrink-0" />
            This request has been closed. No more replies can be added.
          </div>
        )}
      </div>
    </div>
  );
}
