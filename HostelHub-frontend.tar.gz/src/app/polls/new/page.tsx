"use client";
import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useCategories } from "@/hooks/useCategories";
import { useHostels } from "@/hooks/useHostels";
import { useToast } from "@/providers/ToastProvider";
import { ArrowLeft, Send } from "lucide-react";
import clsx from "clsx";

export default function NewPollPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { categories } = useCategories();
  const { data: hostelGroups = [] } = useHostels();

  const [form, setForm] = useState({
    itemName: "", description: "", category: "", maxPrice: "", hostelId: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.itemName.trim()) e.itemName = "Item name is required";
    if (!form.description.trim()) e.description = "Description is required";
    if (!form.category) e.category = "Please select a category";
    if (!form.hostelId) e.hostelId = "Please select your hostel";
    if (form.maxPrice && isNaN(Number(form.maxPrice))) e.maxPrice = "Enter a valid number";
    return e;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setSubmitting(true);
    try {
      const res = await fetch("/api/polls", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Failed");
      const poll = await res.json();
      toast("Request posted successfully!", "success");
      router.push(`/polls/${poll.id}`);
    } catch {
      toast("Failed to post request. Try again.", "error");
      setSubmitting(false);
    }
  };

  const field = (key: keyof typeof form) => ({
    value: form[key],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      setForm(f => ({ ...f, [key]: e.target.value }));
      setErrors(err => { const n = { ...err }; delete n[key]; return n; });
    },
  });

  const inputCls = (key: string) => clsx(
    "w-full px-4 py-2.5 rounded-xl border text-sm text-slate-800 placeholder:text-slate-400",
    "focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:bg-white transition-all bg-slate-50",
    errors[key] ? "border-red-300 bg-red-50" : "border-slate-200"
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50">
      <div className="max-w-xl mx-auto px-4 py-8">
        <button onClick={() => router.back()}
          className="flex items-center gap-1.5 text-slate-500 hover:text-slate-800 mb-6 transition-colors group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span className="text-sm font-medium">Back</span>
        </button>

        <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl p-6 shadow-lg">
          <h1 className="text-xl font-bold text-slate-800 mb-1">Post a Request</h1>
          <p className="text-sm text-slate-500 mb-6">Describe what you're looking for and sellers will respond.</p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {/* Item name */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Item Name <span className="text-red-400">*</span></label>
              <input {...field("itemName")} placeholder="e.g. Physics Textbook, Desk Lamp..." className={inputCls("itemName")} />
              {errors.itemName && <p className="text-xs text-red-500 mt-1">{errors.itemName}</p>}
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Description <span className="text-red-400">*</span></label>
              <textarea {...field("description")} rows={3} placeholder="Describe exactly what you need, condition preference, specific model etc..."
                className={clsx(inputCls("description"), "resize-none leading-relaxed")} />
              {errors.description && <p className="text-xs text-red-500 mt-1">{errors.description}</p>}
            </div>

            {/* Category + Max Price */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">Category <span className="text-red-400">*</span></label>
                <select {...field("category")} className={inputCls("category")}>
                  <option value="">Select...</option>
                  {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
                {errors.category && <p className="text-xs text-red-500 mt-1">{errors.category}</p>}
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">Max Budget (₹)</label>
                <input {...field("maxPrice")} type="number" placeholder="Optional" className={inputCls("maxPrice")} />
                {errors.maxPrice && <p className="text-xs text-red-500 mt-1">{errors.maxPrice}</p>}
              </div>
            </div>

            {/* Hostel */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">Your Hostel <span className="text-red-400">*</span></label>
              <select {...field("hostelId")} className={inputCls("hostelId")}>
                <option value="">Select your hostel...</option>
                {hostelGroups.map(g => (
                  <optgroup key={g.id} label={g.name}>
                    {(g.hostels ?? []).map((h: string) => <option key={h} value={h}>{h}</option>)}
                  </optgroup>
                ))}
              </select>
              {errors.hostelId && <p className="text-xs text-red-500 mt-1">{errors.hostelId}</p>}
            </div>

            <button type="submit" disabled={submitting}
              className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-70 text-white font-semibold py-3 rounded-xl shadow-md shadow-indigo-200 hover:shadow-lg transition-all duration-200 mt-1">
              <Send className="w-4 h-4" />
              {submitting ? "Posting..." : "Post Request"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
