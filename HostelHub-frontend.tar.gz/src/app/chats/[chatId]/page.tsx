"use client";
import { useEffect, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { useChatMessages } from "@/hooks/useChats";
import { useSocket } from "@/providers/SocketProvider";
import MessageBubble from "@/components/chat/MessageBubble";
import ChatInput from "@/components/chat/ChatInput";
import OnlineIndicator from "@/components/chat/OnlineIndicator";
import type { Chat } from "@/types/chat";
import { ArrowLeft, Package } from "lucide-react";
import Link from "next/link";

export default function ChatWindowPage() {
  const { chatId } = useParams<{ chatId: string }>();
  const router = useRouter();
  const { currentUserId, onlineUsers } = useSocket();
  const bottomRef = useRef<HTMLDivElement>(null);

  // Fetch chat metadata
  const { data: chats = [] } = useQuery<Chat[]>({
    queryKey: ["chats"],
    queryFn: async () => {
      const res = await fetch("/api/chats");
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
  const chat = chats.find(c => c.id === chatId);

  const { messages, isLoading, sendMessage, markRead } = useChatMessages(chatId);

  // Mark as read when window is open
  useEffect(() => {
    if (chat) markRead();
  }, [chatId, chat]);

  // Auto-scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const otherId = chat?.participants.find(p => p !== currentUserId) ?? "";
  const otherName = chat?.participantNames[otherId] ?? "Chat";
  const otherAvatar = chat?.participantAvatars[otherId];
  const isOnline = onlineUsers.has(otherId);

  return (
    <div className="flex flex-col h-[calc(100vh-56px)] bg-gradient-to-br from-slate-50 via-white to-indigo-50">

      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 bg-white/80 backdrop-blur-md border-b border-slate-100 shadow-sm z-10">
        <button onClick={() => router.push("/chats")}
          className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="relative flex-shrink-0">
          <img src={otherAvatar} alt={otherName} className="w-9 h-9 rounded-full bg-slate-100" />
          <div className="absolute bottom-0 right-0">
            <OnlineIndicator online={isOnline} size="sm" />
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <p className="font-semibold text-slate-800 text-sm truncate">{otherName}</p>
          <p className="text-xs text-slate-400">{isOnline ? "Online" : "Offline"}</p>
        </div>

        {/* Product context */}
        {chat?.productId && (
          <Link href={`/product/${chat.productId}`}
            className="flex items-center gap-1.5 bg-indigo-50 border border-indigo-100 rounded-xl px-2.5 py-1.5 hover:bg-indigo-100 transition-colors max-w-[140px]">
            {chat.productImageUrl && (
              <img src={chat.productImageUrl} alt="" className="w-6 h-6 rounded-lg object-cover flex-shrink-0" />
            )}
            <span className="text-xs font-medium text-indigo-700 truncate">{chat.productTitle}</span>
          </Link>
        )}
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-0.5">
        {isLoading ? (
          <div className="flex justify-center pt-10">
            <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-500 rounded-full animate-spin" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-3 py-10">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center">
              <Package className="w-7 h-7 text-slate-300" />
            </div>
            <p className="text-slate-400 text-sm">No messages yet. Say hello!</p>
          </div>
        ) : (
          messages.map((msg, i) => {
            const prevMsg = messages[i - 1];
            const showName = !prevMsg || prevMsg.senderId !== msg.senderId;
            return (
              <MessageBubble
                key={msg.id}
                message={msg}
                isOwn={msg.senderId === currentUserId}
                showName={showName}
              />
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <ChatInput onSend={sendMessage} />
    </div>
  );
}
