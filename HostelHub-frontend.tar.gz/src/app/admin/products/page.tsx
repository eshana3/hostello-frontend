"use client";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Package, CheckCircle, XCircle } from "lucide-react";
import clsx from "clsx";

export default function AdminProductsPage() {
  const [search, setSearch] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["admin", "products"],
    queryFn: async () => {
      const res = await fetch("/api/products?limit=50&sold=all");
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const products = (data?.products ?? []).filter((p: { title: string }) =>
    p.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="text-2xl font-bold text-slate-800">Products</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search products..."
            className="pl-9 pr-4 py-2 rounded-xl border border-slate-200 bg-white text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-300 transition-all w-56" />
        </div>
      </div>

      <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/60">
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Product</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Category</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Hostel</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Price</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Status</th>
                <th className="text-left px-4 py-3 font-semibold text-slate-600">Seller</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i}><td colSpan={6} className="px-4 py-3"><div className="h-4 bg-slate-100 rounded animate-pulse" /></td></tr>
                ))
              ) : products.map((p: { id: string; imageUrl: string; title: string; category: string; hostelId: string; price: number; sold: boolean; sellerName: string }) => (
                <tr key={p.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <img src={p.imageUrl} alt={p.title} className="w-8 h-8 rounded-lg object-cover bg-slate-100 flex-shrink-0" />
                      <span className="font-medium text-slate-800 line-clamp-1">{p.title}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-500">{p.category}</td>
                  <td className="px-4 py-3 text-slate-500">{p.hostelId}</td>
                  <td className="px-4 py-3 font-semibold text-indigo-600">₹{p.price.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className={clsx("flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full w-fit",
                      p.sold ? "bg-slate-100 text-slate-500" : "bg-emerald-100 text-emerald-700")}>
                      {p.sold ? <XCircle className="w-3 h-3" /> : <CheckCircle className="w-3 h-3" />}
                      {p.sold ? "Sold" : "Active"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500">{p.sellerName}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!isLoading && products.length === 0 && (
            <div className="flex flex-col items-center py-12 gap-3 text-slate-400">
              <Package className="w-8 h-8" />
              <p className="text-sm">No products found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
