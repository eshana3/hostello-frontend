"use client";
import { useAdminStats } from "@/hooks/useAdmin";
import { Crown } from "lucide-react";

export default function AdminUsersPage() {
  const { data: stats, isLoading } = useAdminStats();

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">Users</h1>

      <div className="backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl shadow overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
          <Crown className="w-4 h-4 text-amber-500" />
          <h3 className="text-sm font-bold text-slate-700">Top Active Users</h3>
        </div>
        <div className="divide-y divide-slate-50">
          {isLoading ? (
            [...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-4 animate-pulse">
                <div className="w-10 h-10 rounded-full bg-slate-200" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 bg-slate-200 rounded w-1/4" />
                  <div className="h-2.5 bg-slate-200 rounded w-1/3" />
                </div>
              </div>
            ))
          ) : (stats?.topUsers ?? []).map((u: { id: string; avatar: string; name: string; hostel: string; listings: number; sold: number }, i: number) => (
            <div key={u.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-50/60 transition-colors">
              <span className="text-lg font-black text-slate-300 w-6 text-center">{i + 1}</span>
              <img src={u.avatar} alt={u.name} className="w-10 h-10 rounded-full" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-800">{u.name}</p>
                <p className="text-xs text-slate-400">{u.hostel}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-indigo-600">{u.listings} listings</p>
                <p className="text-xs text-slate-400">{u.sold} sold</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
