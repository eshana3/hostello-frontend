import clsx from "clsx";
import type { Message } from "@/types/chat";
import { Check, CheckCheck } from "lucide-react";

interface MessageBubbleProps {
  message: Message;
  isOwn: boolean;
  showName?: boolean;
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true });
}

export default function MessageBubble({ message, isOwn, showName }: MessageBubbleProps) {
  if (message.type === "system") {
    return (
      <div className="flex justify-center my-2">
        <span className="text-xs text-slate-400 bg-slate-100 px-3 py-1 rounded-full">{message.content}</span>
      </div>
    );
  }

  return (
    <div className={clsx("flex gap-2 mb-1", isOwn ? "flex-row-reverse" : "flex-row")}>
      {/* Avatar */}
      {!isOwn && (
        <img
          src={`https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(message.senderName)}&backgroundColor=6366f1`}
          alt={message.senderName}
          className="w-7 h-7 rounded-full flex-shrink-0 mt-1"
        />
      )}

      <div className={clsx("flex flex-col max-w-[70%]", isOwn ? "items-end" : "items-start")}>
        {showName && !isOwn && (
          <span className="text-xs text-slate-500 font-medium mb-1 ml-1">{message.senderName}</span>
        )}

        <div
          className={clsx(
            "px-3.5 py-2 rounded-2xl text-sm leading-relaxed shadow-sm",
            isOwn
              ? "bg-indigo-600 text-white rounded-br-sm"
              : "bg-white border border-slate-100 text-slate-800 rounded-bl-sm"
          )}
        >
          {message.content}
        </div>

        <div className={clsx("flex items-center gap-1 mt-0.5 px-1", isOwn ? "flex-row-reverse" : "flex-row")}>
          <span className="text-[10px] text-slate-400">{formatTime(message.createdAt)}</span>
          {isOwn && (
            message.read
              ? <CheckCheck className="w-3 h-3 text-indigo-400" />
              : <Check className="w-3 h-3 text-slate-300" />
          )}
        </div>
      </div>
    </div>
  );
}
