"use client";
import { useProducts } from "@/hooks/useProducts";
import ProductCard from "./ProductCard";
import { CheckCircle2 } from "lucide-react";

export default function RecentlySold() {
  const { data, isLoading } = useProducts({ sold: true, limit: 6 });

  if (!isLoading && !data?.products?.length) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex items-center gap-2 mb-6">
        <CheckCircle2 className="w-5 h-5 text-green-600" />
        <h2 className="text-2xl font-bold text-gray-900">Recently Sold</h2>
      </div>

      {isLoading ? (
        <div className="flex gap-4 overflow-x-auto pb-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="min-w-[180px] h-56 bg-white rounded-xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
          {(data?.products ?? []).map((p) => (
            <div key={p.id} className="min-w-[200px] max-w-[200px]">
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
