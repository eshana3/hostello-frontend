"use client";
import Link from "next/link";
import type { Product } from "@/types";
import WishlistButton from "./WishlistButton";
import clsx from "clsx";

interface ProductCardProps {
  product: Product;
}

const conditionColor: Record<string, string> = {
  "Like New": "bg-emerald-100 text-emerald-700",
  "Good": "bg-blue-100 text-blue-700",
  "Fair": "bg-amber-100 text-amber-700",
  "Poor": "bg-red-100 text-red-700",
};

export default function ProductCard({ product: p }: ProductCardProps) {
  return (
    <div className="group relative backdrop-blur-sm bg-white/80 border border-white/60 rounded-2xl overflow-hidden shadow hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
      <Link href={`/product/${p.id}`}>
        <div className="relative aspect-square overflow-hidden bg-slate-100">
          <img
            src={p.imageUrl}
            alt={p.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {p.sold && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="bg-white text-slate-800 text-xs font-black px-3 py-1 rounded-full tracking-wider">SOLD</span>
            </div>
          )}
          {p.negotiable && !p.sold && (
            <div className="absolute bottom-2 left-2">
              <span className="bg-violet-600/90 text-white text-[10px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-sm">
                Negotiable
              </span>
            </div>
          )}
        </div>
      </Link>

      {/* Wishlist button on hover */}
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
        <WishlistButton productId={p.id} size="sm" />
      </div>

      <div className="p-3">
        <Link href={`/product/${p.id}`}>
          <p className="text-sm font-semibold text-slate-700 line-clamp-2 leading-snug mb-2 hover:text-indigo-600 transition-colors">
            {p.title}
          </p>
        </Link>
        <div className="flex items-center justify-between gap-1 flex-wrap">
          <span className="text-base font-black text-indigo-600">₹{p.price.toLocaleString()}</span>
          <span className={clsx("text-[10px] font-semibold px-2 py-0.5 rounded-full", conditionColor[p.condition] || "bg-slate-100 text-slate-600")}>
            {p.condition}
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1.5">{p.hostelId}</p>
      </div>
    </div>
  );
}
