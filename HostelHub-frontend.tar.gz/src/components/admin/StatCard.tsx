import clsx from "clsx";
import type { LucideIcon } from "lucide-react";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  color: "indigo" | "emerald" | "violet" | "rose" | "amber";
  sub?: string;
  live?: boolean;
}

const colorMap = {
  indigo:  { bg: "bg-indigo-100",  text: "text-indigo-600",  border: "border-indigo-100" },
  emerald: { bg: "bg-emerald-100", text: "text-emerald-600", border: "border-emerald-100" },
  violet:  { bg: "bg-violet-100",  text: "text-violet-600",  border: "border-violet-100" },
  rose:    { bg: "bg-rose-100",    text: "text-rose-600",    border: "border-rose-100" },
  amber:   { bg: "bg-amber-100",   text: "text-amber-600",   border: "border-amber-100" },
};

export default function StatCard({ label, value, icon: Icon, color, sub, live }: StatCardProps) {
  const c = colorMap[color];
  return (
    <div className={clsx("backdrop-blur-sm bg-white/80 border rounded-2xl p-5 shadow hover:shadow-md transition-all duration-200", c.border)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">{label}</p>
          <p className={clsx("text-3xl font-black", c.text)}>{value}</p>
          {sub && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
        </div>
        <div className={clsx("w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0", c.bg)}>
          <Icon className={clsx("w-5 h-5", c.text)} />
        </div>
      </div>
      {live && (
        <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-slate-100">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-emerald-600 font-medium">Live · updates every 30s</span>
        </div>
      )}
    </div>
  );
}
