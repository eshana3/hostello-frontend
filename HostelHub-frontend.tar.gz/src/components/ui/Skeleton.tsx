import clsx from "clsx";

interface SkeletonProps {
  className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
  return (
    <div className={clsx(
      "animate-pulse rounded-lg bg-slate-200 dark:bg-slate-700",
      className
    )} />
  );
}

export function SkeletonCard() {
  return (
    <div className="backdrop-blur-sm bg-white/80 dark:bg-slate-800/80 border border-white/60 dark:border-white/10 rounded-2xl p-4 shadow">
      <div className="flex items-center gap-3 mb-3">
        <Skeleton className="w-10 h-10 rounded-full" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-3 w-1/3" />
          <Skeleton className="h-2.5 w-1/2" />
        </div>
      </div>
      <Skeleton className="h-3 w-full mb-2" />
      <Skeleton className="h-3 w-4/5" />
    </div>
  );
}

export function SkeletonProductCard() {
  return (
    <div className="backdrop-blur-sm bg-white/80 dark:bg-slate-800/80 border border-white/60 dark:border-white/10 rounded-2xl overflow-hidden shadow">
      <Skeleton className="aspect-square w-full rounded-none" />
      <div className="p-3 space-y-2">
        <Skeleton className="h-3 w-3/4" />
        <Skeleton className="h-3 w-1/2" />
        <Skeleton className="h-4 w-1/3" />
      </div>
    </div>
  );
}
