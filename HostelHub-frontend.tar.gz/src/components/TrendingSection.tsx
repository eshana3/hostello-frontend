"use client";
import { useTrendingProducts } from "@/hooks/useProducts";
import ProductCard from "./ProductCard";
import { TrendingUp } from "lucide-react";

export default function TrendingSection() {
  const { data: products, isLoading } = useTrendingProducts();

  return (
    <section className="bg-indigo-50 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="w-5 h-5 text-indigo-600" />
          <h2 className="text-2xl font-bold text-gray-900">Trending Now</h2>
        </div>

        {isLoading ? (
          <div className="flex gap-4 overflow-x-auto pb-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="min-w-[180px] h-56 bg-white rounded-xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
            {(products ?? []).map((p) => (
              <div key={p.id} className="min-w-[200px] max-w-[200px]">
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
