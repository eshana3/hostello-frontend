import Link from "next/link";
import { CATEGORIES } from "@/hooks/useCategories";

export default function CategoryTiles() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Browse by Category</h2>
      <div className="grid grid-cols-4 sm:grid-cols-4 md:grid-cols-8 gap-3">
        {CATEGORIES.map((cat) => (
          <Link
            key={cat.id}
            href={`/products?category=${cat.id}`}
            className={`flex flex-col items-center gap-2 p-3 rounded-xl ${cat.bgColor} hover:scale-105 transition-transform cursor-pointer`}
          >
            <span className="text-3xl">{cat.emoji}</span>
            <span className={`text-xs font-semibold ${cat.color}`}>{cat.name}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}
