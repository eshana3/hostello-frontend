"use client";
import Link from "next/link";
import { useRecentlyViewed } from "@/hooks/useRecentlyViewed";

export default function RecentlyViewed() {
  const { products, clear } = useRecentlyViewed();
  if (!products.length) return null;

  return (
    <section className="py-8 px-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-slate-800">Recently Viewed</h2>
        <button onClick={clear} className="text-xs text-slate-400 hover:text-slate-600 transition-colors">Clear</button>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
        {products.map(p => (
          <Link key={p.id} href={`/product/${p.id}`}
            className="flex-shrink-0 w-36 group">
            <div className="aspect-square rounded-xl overflow-hidden bg-slate-100 mb-2">
              <img src={p.imageUrl} alt={p.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
            </div>
            <p className="text-xs text-slate-700 font-medium line-clamp-2 leading-snug">{p.title}</p>
            <p className="text-sm font-bold text-indigo-600 mt-0.5">₹{p.price.toLocaleString()}</p>
          </Link>
        ))}
      </div>
    </section>
  );
}
