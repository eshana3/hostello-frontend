"use client";
import Link from "next/link";
import { useProducts } from "@/hooks/useProducts";
import ProductCard from "./ProductCard";
import { Clock } from "lucide-react";

export default function LatestProducts() {
  const { data, isLoading } = useProducts({ limit: 8, page: 1 });

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-indigo-600" />
          <h2 className="text-2xl font-bold text-gray-900">Latest Listings</h2>
        </div>
        <Link href="/products" className="text-sm text-indigo-600 font-medium hover:underline">
          View all →
        </Link>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-56 bg-white rounded-xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {(data?.products ?? []).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}
