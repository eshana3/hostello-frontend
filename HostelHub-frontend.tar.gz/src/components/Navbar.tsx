"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ShoppingBag, Heart, Search, Menu, X, Home, MessageCircle, ClipboardList, Plus, Sun, Moon } from "lucide-react";
import { useState } from "react";
import { useWishlist } from "@/hooks/useWishlist";
import { useChats } from "@/hooks/useChats";
import { useTheme } from "@/providers/ThemeProvider";
import NotificationDropdown from "@/components/NotificationDropdown";
import clsx from "clsx";

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const { count: wishlistCount } = useWishlist();
  const { totalUnread } = useChats();
  const { theme, toggleTheme } = useTheme();

  const links = [
    { href: "/",         label: "Home",     icon: Home },
    { href: "/products", label: "Browse",   icon: Search },
    { href: "/polls",    label: "Requests", icon: ClipboardList },
    { href: "/chats",    label: "Chats",    icon: MessageCircle, badge: totalUnread },
    { href: "/wishlist", label: "Wishlist", icon: Heart,         badge: wishlistCount },
  ];

  return (
    <nav className="sticky top-0 z-40 backdrop-blur-md bg-white/80 dark:bg-slate-900/80 border-b border-white/60 dark:border-white/10 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-black text-lg text-indigo-600 dark:text-indigo-400 tracking-tight">
          <ShoppingBag className="w-5 h-5" />
          <span className="hidden sm:inline">HostelMarket</span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-1">
          {links.map(({ href, label, icon: Icon, badge }) => (
            <Link key={href} href={href}
              className={clsx(
                "relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all",
                pathname === href || (href !== "/" && pathname.startsWith(href + "/"))
                  ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400"
                  : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-700/50"
              )}>
              <Icon className="w-4 h-4" />
              {label}
              {badge !== undefined && badge > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-0.5">
                  {badge > 9 ? "9+" : badge}
                </span>
              )}
            </Link>
          ))}
        </div>

        {/* Right: actions */}
        <div className="flex items-center gap-1.5">
          {/* Create Request */}
          <Link href="/polls/new"
            className="hidden sm:flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-3 py-1.5 rounded-lg shadow-sm shadow-indigo-200 dark:shadow-indigo-900 transition-all duration-200">
            <Plus className="w-3.5 h-3.5" />
            Request
          </Link>

          {/* Notifications */}
          <NotificationDropdown />

          {/* Dark mode toggle */}
          <button onClick={toggleTheme}
            className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-slate-200 transition-all">
            {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* Mobile menu */}
          <button onClick={() => setOpen(o => !o)} className="md:hidden p-1.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="md:hidden border-t border-slate-100 dark:border-slate-700 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-4 py-3 flex flex-col gap-1">
          {links.map(({ href, label, icon: Icon, badge }) => (
            <Link key={href} href={href} onClick={() => setOpen(false)}
              className={clsx(
                "relative flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                pathname === href || (href !== "/" && pathname.startsWith(href + "/"))
                  ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400"
                  : "text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50"
              )}>
              <Icon className="w-4 h-4" />
              {label}
              {badge !== undefined && badge > 0 && (
                <span className="ml-auto min-w-[20px] h-5 bg-rose-500 text-white text-xs font-bold rounded-full flex items-center justify-center px-1">
                  {badge > 9 ? "9+" : badge}
                </span>
              )}
            </Link>
          ))}
          <Link href="/polls/new" onClick={() => setOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-semibold bg-indigo-600 text-white mt-1">
            <Plus className="w-4 h-4" />Post a Request
          </Link>
        </div>
      )}
    </nav>
  );
}
