import Link from "next/link";
import { Search, TrendingUp } from "lucide-react";

export default function HeroBanner() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 text-white">
      {/* decorative blobs */}
      <div className="absolute -top-16 -right-16 w-72 h-72 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-10 -left-10 w-56 h-56 bg-purple-400/20 rounded-full blur-2xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-1 bg-white/20 text-white text-sm font-medium px-3 py-1 rounded-full mb-4">
            <TrendingUp className="w-4 h-4" /> Campus Marketplace
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold leading-tight mb-4">
            Buy &amp; Sell<br />
            <span className="text-indigo-200">Within Your Hostel</span>
          </h1>
          <p className="text-indigo-100 text-lg mb-8">
            Find textbooks, electronics, clothes &amp; more — listed by students in your own block.
          </p>

          {/* Quick search */}
          <form action="/products" method="get" className="flex gap-2 max-w-md">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                name="search"
                type="text"
                placeholder="Search products..."
                className="w-full pl-10 pr-4 py-3 rounded-xl text-gray-900 focus:outline-none focus:ring-2 focus:ring-white/50"
              />
            </div>
            <button
              type="submit"
              className="bg-white text-indigo-600 font-semibold px-5 py-3 rounded-xl hover:bg-indigo-50 transition"
            >
              Search
            </button>
          </form>

          {/* Stats */}
          <div className="mt-8 flex gap-8 text-sm text-indigo-200">
            <div><span className="text-white font-bold text-xl">200+</span><br />Active Listings</div>
            <div><span className="text-white font-bold text-xl">38</span><br />Hostels</div>
            <div><span className="text-white font-bold text-xl">8</span><br />Categories</div>
          </div>
        </div>
      </div>
    </section>
  );
}
