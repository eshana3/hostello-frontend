"use client";
import { Heart } from "lucide-react";
import { useWishlist } from "@/hooks/useWishlist";
import clsx from "clsx";

interface WishlistButtonProps {
  productId: string;
  size?: "sm" | "md";
  className?: string;
}

export default function WishlistButton({ productId, size = "md", className }: WishlistButtonProps) {
  const { toggle, isWishlisted } = useWishlist();
  const wishlisted = isWishlisted(productId);

  return (
    <button
      onClick={e => { e.preventDefault(); e.stopPropagation(); toggle(productId); }}
      className={clsx(
        "rounded-full flex items-center justify-center transition-all duration-200",
        size === "sm" ? "w-7 h-7" : "w-9 h-9",
        wishlisted
          ? "bg-rose-500 text-white shadow-md shadow-rose-200"
          : "bg-white/80 backdrop-blur-sm text-slate-400 hover:text-rose-500 hover:bg-white shadow",
        className
      )}
      title={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
    >
      <Heart
        className={clsx(size === "sm" ? "w-3.5 h-3.5" : "w-4 h-4", wishlisted && "fill-current")}
      />
    </button>
  );
}
