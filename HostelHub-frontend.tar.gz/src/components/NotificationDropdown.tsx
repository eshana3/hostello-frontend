"use client";
import { useState, useRef, useEffect } from "react";
import { Bell, MessageCircle, ClipboardList, Heart, CheckCircle, Package, Info, X } from "lucide-react";
import { useNotifications } from "@/hooks/useNotifications";
import Link from "next/link";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import type { Notification, NotificationType } from "@/types/notification";

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

const TYPE_ICON: Record<NotificationType, React.ReactNode> = {
  message:    <MessageCircle className="w-3.5 h-3.5" />,
  poll_reply: <ClipboardList className="w-3.5 h-3.5" />,
  wishlist:   <Heart className="w-3.5 h-3.5" />,
  sold:       <CheckCircle className="w-3.5 h-3.5" />,
  listing:    <Package className="w-3.5 h-3.5" />,
  system:     <Info className="w-3.5 h-3.5" />,
};

const TYPE_COLOR: Record<NotificationType, string> = {
  message:    "bg-indigo-100 text-indigo-600 dark:bg-indigo-900/50 dark:text-indigo-400",
  poll_reply: "bg-amber-100 text-amber-600 dark:bg-amber-900/50 dark:text-amber-400",
  wishlist:   "bg-rose-100 text-rose-600 dark:bg-rose-900/50 dark:text-rose-400",
  sold:       "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/50 dark:text-emerald-400",
  listing:    "bg-violet-100 text-violet-600 dark:bg-violet-900/50 dark:text-violet-400",
  system:     "bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-400",
};

function NotifItem({ n, onRead }: { n: Notification; onRead: (id: string) => void }) {
  const router = useRouter();

  const handleClick = () => {
    onRead(n.id);
    if (n.link) router.push(n.link);
  };

  return (
    <button onClick={handleClick}
      className={clsx(
        "w-full flex items-start gap-3 px-4 py-3 text-left transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/50",
        !n.read && "bg-indigo-50/60 dark:bg-indigo-950/30"
      )}>
      {/* Icon or avatar */}
      <div className="relative flex-shrink-0 mt-0.5">
        {n.avatar ? (
          <img src={n.avatar} alt="" className="w-8 h-8 rounded-full" />
        ) : (
          <div className={clsx("w-8 h-8 rounded-full flex items-center justify-center", TYPE_COLOR[n.type])}>
            {TYPE_ICON[n.type]}
          </div>
        )}
        {!n.read && (
          <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-indigo-500 rounded-full border-2 border-white dark:border-slate-800" />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className={clsx("text-xs leading-snug", n.read ? "text-slate-600 dark:text-slate-400" : "text-slate-800 dark:text-slate-100 font-semibold")}>
          {n.title}
        </p>
        <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5 line-clamp-1">{n.message}</p>
        <p className="text-[10px] text-slate-300 dark:text-slate-600 mt-1">{timeAgo(n.createdAt)}</p>
      </div>
    </button>
  );
}

export default function NotificationDropdown() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { data, markAllRead, markOneRead } = useNotifications();

  const notifications = data?.notifications?.slice(0, 6) ?? [];
  const unreadCount = data?.unreadCount ?? 0;

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div ref={ref} className="relative">
      {/* Bell button */}
      <button
        onClick={() => setOpen(o => !o)}
        className={clsx(
          "relative p-2 rounded-xl transition-all",
          open
            ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600"
            : "text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-slate-200"
        )}>
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 min-w-[16px] h-4 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center px-0.5 leading-none">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md border border-white/60 dark:border-white/10 rounded-2xl shadow-xl z-50 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100 dark:border-slate-700">
            <span className="text-sm font-bold text-slate-800 dark:text-slate-100">Notifications</span>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <button onClick={markAllRead}
                  className="text-xs text-indigo-500 hover:text-indigo-700 dark:text-indigo-400 font-medium transition-colors">
                  Mark all read
                </button>
              )}
              <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* List */}
          <div className="max-h-80 overflow-y-auto divide-y divide-slate-50 dark:divide-slate-700/50">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center py-10 gap-2">
                <Bell className="w-8 h-8 text-slate-200 dark:text-slate-600" />
                <p className="text-sm text-slate-400 dark:text-slate-500">No notifications yet</p>
              </div>
            ) : (
              notifications.map(n => (
                <NotifItem key={n.id} n={n} onRead={id => { markOneRead(id); }} />
              ))
            )}
          </div>

          {/* Footer */}
          <div className="border-t border-slate-100 dark:border-slate-700 px-4 py-2.5">
            <Link href="/notifications" onClick={() => setOpen(false)}
              className="text-xs text-indigo-500 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-medium transition-colors">
              See all notifications →
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
