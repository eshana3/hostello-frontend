"use client";
import { useCategories } from "@/hooks/useCategories";
import { useHostels } from "@/hooks/useHostels";
import type { ProductFilters } from "@/types";
import { SlidersHorizontal } from "lucide-react";

interface Props {
  filters: ProductFilters;
  onFilterChange: (key: string, value: string | null) => void;
}

const CONDITIONS = [
  { id: "new",      label: "New" },
  { id: "like_new", label: "Like New" },
  { id: "good",     label: "Good" },
  { id: "fair",     label: "Fair" },
  { id: "poor",     label: "Poor" },
];

export default function FilterSidebar({ filters, onFilterChange }: Props) {
  const { categories } = useCategories();
  const { data: hostelGroups } = useHostels();

  return (
    <aside className="w-60 shrink-0 hidden lg:block">
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 sticky top-20 space-y-5">
        <div className="flex items-center gap-2 font-bold text-gray-800">
          <SlidersHorizontal className="w-4 h-4" /> Filters
        </div>

        {/* Category */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase mb-2">Category</label>
          <select
            value={filters.category ?? ""}
            onChange={(e) => onFilterChange("category", e.target.value || null)}
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>
            ))}
          </select>
        </div>

        {/* Hostel */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase mb-2">Hostel</label>
          <select
            value={filters.hostel ?? ""}
            onChange={(e) => onFilterChange("hostel", e.target.value || null)}
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
          >
            <option value="">All Hostels</option>
            {(hostelGroups ?? []).map((group) => (
              <optgroup key={group.type} label={group.label}>
                {group.hostels.map((h) => (
                  <option key={h.id} value={h.id}>{h.name}</option>
                ))}
              </optgroup>
            ))}
          </select>
        </div>

        {/* Condition */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase mb-2">Condition</label>
          <div className="space-y-1">
            {CONDITIONS.map((c) => (
              <label key={c.id} className="flex items-center gap-2 text-sm cursor-pointer hover:text-indigo-600">
                <input
                  type="radio"
                  name="condition"
                  value={c.id}
                  checked={filters.condition === c.id}
                  onChange={() => onFilterChange("condition", c.id)}
                  className="accent-indigo-600"
                />
                {c.label}
              </label>
            ))}
            {filters.condition && (
              <button onClick={() => onFilterChange("condition", null)}
                className="text-xs text-indigo-500 underline mt-1">Clear</button>
            )}
          </div>
        </div>

        {/* Price Range */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase mb-2">Price Range (₹)</label>
          <div className="flex gap-2">
            <input
              type="number" placeholder="Min"
              value={filters.minPrice ?? ""}
              onChange={(e) => onFilterChange("minPrice", e.target.value || null)}
              className="w-1/2 border border-gray-200 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
            />
            <input
              type="number" placeholder="Max"
              value={filters.maxPrice ?? ""}
              onChange={(e) => onFilterChange("maxPrice", e.target.value || null)}
              className="w-1/2 border border-gray-200 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-300"
            />
          </div>
        </div>

        {/* Clear all */}
        <button
          onClick={() => {
            ["category","hostel","condition","minPrice","maxPrice","search"].forEach((k) =>
              onFilterChange(k, null)
            );
          }}
          className="w-full border border-gray-200 rounded-lg py-2 text-sm text-gray-600 hover:bg-gray-50 transition"
        >
          Clear All Filters
        </button>
      </div>
    </aside>
  );
}
