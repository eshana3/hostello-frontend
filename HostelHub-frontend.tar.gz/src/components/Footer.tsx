import Link from "next/link";
import { ShoppingBag } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 mt-12">
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-500">
        <div className="flex items-center gap-2 font-semibold text-gray-700">
          <ShoppingBag className="w-5 h-5 text-indigo-600" />
          HostelMart
        </div>
        <p>© {new Date().getFullYear()} HostelMart. Campus use only.</p>
        <div className="flex gap-4">
          <Link href="/products" className="hover:text-indigo-600">Browse</Link>
          <Link href="/" className="hover:text-indigo-600">Home</Link>
        </div>
      </div>
    </footer>
  );
}
