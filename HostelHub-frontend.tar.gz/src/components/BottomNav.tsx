"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, MessageCircle, Heart, ClipboardList } from "lucide-react";
import { useWishlist } from "@/hooks/useWishlist";
import { useChats } from "@/hooks/useChats";
import clsx from "clsx";

const links = [
  { href: "/",         label: "Home",     icon: Home },
  { href: "/products", label: "Browse",   icon: Search },
  { href: "/polls",    label: "Requests", icon: ClipboardList },
  { href: "/chats",    label: "Chats",    icon: MessageCircle, badgeKey: "chats" },
  { href: "/wishlist", label: "Saved",    icon: Heart,         badgeKey: "wishlist" },
];

export default function BottomNav() {
  const pathname = usePathname();
  const { count: wishlistCount } = useWishlist();
  const { totalUnread: chatCount } = useChats();

  const getBadge = (key?: string) => {
    if (key === "chats")    return chatCount;
    if (key === "wishlist") return wishlistCount;
    return 0;
  };

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-t border-slate-100 dark:border-slate-700 safe-area-bottom">
      <div className="flex items-center justify-around px-2 py-2">
        {links.map(({ href, label, icon: Icon, badgeKey }) => {
          const active = pathname === href || (href !== "/" && pathname.startsWith(href));
          const badge = getBadge(badgeKey);
          return (
            <Link key={href} href={href}
              className={clsx(
                "relative flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all",
                active ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 dark:text-slate-500"
              )}>
              <div className="relative">
                <Icon className={clsx("w-5 h-5", active && "scale-110 transition-transform")} />
                {badge > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[14px] h-3.5 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center px-0.5">
                    {badge > 9 ? "9+" : badge}
                  </span>
                )}
              </div>
              <span className={clsx("text-[10px] font-medium", active ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 dark:text-slate-500")}>
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
